import 'package:izza_auliyai_rabby_s_application3/core/app_export.dart';

class ApiClient {}
