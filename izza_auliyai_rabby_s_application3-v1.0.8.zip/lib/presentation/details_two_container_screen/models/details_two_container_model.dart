// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [details_two_container_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class DetailsTwoContainerModel extends Equatable {
  DetailsTwoContainerModel() {}

  DetailsTwoContainerModel copyWith() {
    return DetailsTwoContainerModel();
  }

  @override
  List<Object?> get props => [];
}
